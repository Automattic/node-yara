cmd_Release/obj.target/yara/src/yara.o := c++ -o Release/obj.target/yara/src/yara.o ../src/yara.cc '-DNODE_GYP_MODULE_NAME=yara' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_DARWIN_USE_64_BIT_INODE=1' '-D_LARGEFILE_SOURCE' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/src -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/deps/openssl/config -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/deps/openssl/openssl/include -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/deps/uv/include -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/deps/zlib -I/Users/johnwebb/Library/Caches/node-gyp/26.13.0/deps/v8/include -I../node_modules/nan -I../build/yara/include  -O3 -gdwarf-2 -fno-strict-aliasing -mmacosx-version-min=13.5 -arch arm64 -Wall -Wendif-labels -W -Wno-unused-parameter -std=gnu++20 -stdlib=libc++ -fno-rtti -MMD -MF ./Release/.deps/Release/obj.target/yara/src/yara.o.d.raw -I/opt/homebrew/opt/libmagic/include -I/opt/homebrew/opt/openssl@3/include  -c
Release/obj.target/yara/src/yara.o: ../src/yara.cc ../src/yara.h \
  ../node_modules/nan/nan.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_version.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/errno.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/version.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/unix.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/threadpool.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/darwin.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/common.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8config.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-array-buffer.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-local-handle.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-handle-base.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-internal.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-memory-span.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-object.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/garbage-collected.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/api-constants.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/platform.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/source-location.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-source-location.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-platform.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/trace-trait.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/type-traits.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/name-provider.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-maybe.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/conditional-stack-allocated.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/macros.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/compiler-specific.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-persistent-handle.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-weak-callback-info.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-primitive.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-data.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-value.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-sandbox.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-traced-handle.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-container.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-context.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-snapshot.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-isolate.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-callbacks.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-promise.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-debug.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-script.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-message.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-embedder-heap.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-exception.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-function-callback.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-microtask.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-statistics.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-unwinder.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-embedder-state-scope.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-date.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-extension.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-external.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-function.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-template.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-initialization.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-json.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-locker.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-microtask-queue.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-primitive-object.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-proxy.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-regexp.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-typed-array.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-value-serializer.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-version.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-wasm.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_api_types.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/js_native_api_types.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_buffer.h \
  /Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_object_wrap.h \
  ../node_modules/nan/nan_callbacks.h \
  ../node_modules/nan/nan_callbacks_12_inl.h \
  ../node_modules/nan/nan_maybe_43_inl.h \
  ../node_modules/nan/nan_converters.h \
  ../node_modules/nan/nan_converters_43_inl.h \
  ../node_modules/nan/nan_new.h \
  ../node_modules/nan/nan_implementation_12_inl.h \
  ../node_modules/nan/nan_persistent_12_inl.h \
  ../node_modules/nan/nan_weak.h ../node_modules/nan/nan_object_wrap.h \
  ../node_modules/nan/nan_private.h \
  ../node_modules/nan/nan_typedarray_contents.h \
  ../node_modules/nan/nan_json.h ../node_modules/nan/nan_scriptorigin.h \
  ../build/yara/include/yara.h ../build/yara/include/yara/compiler.h \
  ../build/yara/include/yara/ahocorasick.h \
  ../build/yara/include/yara/atoms.h ../build/yara/include/yara/limits.h \
  ../build/yara/include/yara/utils.h \
  ../build/yara/include/yara/strutils.h \
  ../build/yara/include/yara/integers.h ../build/yara/include/yara/re.h \
  ../build/yara/include/yara/arena.h ../build/yara/include/yara/stream.h \
  ../build/yara/include/yara/sizedstr.h \
  ../build/yara/include/yara/types.h \
  ../build/yara/include/yara/bitmask.h ../build/yara/include/yara/hash.h \
  ../build/yara/include/yara/stopwatch.h \
  ../build/yara/include/yara/threading.h \
  ../build/yara/include/yara/notebook.h \
  ../build/yara/include/yara/filemap.h \
  ../build/yara/include/yara/error.h \
  ../build/yara/include/yara/libyara.h ../build/yara/include/yara/mem.h \
  ../build/yara/include/yara/modules.h ../build/yara/include/yara/exec.h \
  ../build/yara/include/yara/rules.h \
  ../build/yara/include/yara/scanner.h ../build/yara/include/yara/scan.h \
  ../build/yara/include/yara/object.h
../src/yara.cc:
../src/yara.h:
../node_modules/nan/nan.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_version.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/errno.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/version.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/unix.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/threadpool.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/uv/darwin.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/common.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8config.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-array-buffer.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-local-handle.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-handle-base.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-internal.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-memory-span.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-object.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/garbage-collected.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/api-constants.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/platform.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/source-location.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-source-location.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-platform.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/trace-trait.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/type-traits.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/name-provider.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-maybe.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/conditional-stack-allocated.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/macros.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/cppgc/internal/compiler-specific.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-persistent-handle.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-weak-callback-info.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-primitive.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-data.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-value.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-sandbox.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-traced-handle.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-container.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-context.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-snapshot.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-isolate.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-callbacks.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-promise.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-debug.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-script.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-message.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-embedder-heap.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-exception.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-function-callback.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-microtask.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-statistics.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-unwinder.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-embedder-state-scope.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-date.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-extension.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-external.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-function.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-template.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-initialization.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-json.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-locker.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-microtask-queue.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-primitive-object.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-proxy.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-regexp.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-typed-array.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-value-serializer.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-version.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/v8-wasm.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_api_types.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/js_native_api_types.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_buffer.h:
/Users/johnwebb/Library/Caches/node-gyp/26.13.0/include/node/node_object_wrap.h:
../node_modules/nan/nan_callbacks.h:
../node_modules/nan/nan_callbacks_12_inl.h:
../node_modules/nan/nan_maybe_43_inl.h:
../node_modules/nan/nan_converters.h:
../node_modules/nan/nan_converters_43_inl.h:
../node_modules/nan/nan_new.h:
../node_modules/nan/nan_implementation_12_inl.h:
../node_modules/nan/nan_persistent_12_inl.h:
../node_modules/nan/nan_weak.h:
../node_modules/nan/nan_object_wrap.h:
../node_modules/nan/nan_private.h:
../node_modules/nan/nan_typedarray_contents.h:
../node_modules/nan/nan_json.h:
../node_modules/nan/nan_scriptorigin.h:
../build/yara/include/yara.h:
../build/yara/include/yara/compiler.h:
../build/yara/include/yara/ahocorasick.h:
../build/yara/include/yara/atoms.h:
../build/yara/include/yara/limits.h:
../build/yara/include/yara/utils.h:
../build/yara/include/yara/strutils.h:
../build/yara/include/yara/integers.h:
../build/yara/include/yara/re.h:
../build/yara/include/yara/arena.h:
../build/yara/include/yara/stream.h:
../build/yara/include/yara/sizedstr.h:
../build/yara/include/yara/types.h:
../build/yara/include/yara/bitmask.h:
../build/yara/include/yara/hash.h:
../build/yara/include/yara/stopwatch.h:
../build/yara/include/yara/threading.h:
../build/yara/include/yara/notebook.h:
../build/yara/include/yara/filemap.h:
../build/yara/include/yara/error.h:
../build/yara/include/yara/libyara.h:
../build/yara/include/yara/mem.h:
../build/yara/include/yara/modules.h:
../build/yara/include/yara/exec.h:
../build/yara/include/yara/rules.h:
../build/yara/include/yara/scanner.h:
../build/yara/include/yara/scan.h:
../build/yara/include/yara/object.h:
