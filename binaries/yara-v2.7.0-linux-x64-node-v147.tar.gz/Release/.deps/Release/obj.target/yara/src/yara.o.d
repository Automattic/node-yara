cmd_Release/obj.target/yara/src/yara.o := g++ -o Release/obj.target/yara/src/yara.o ../src/yara.cc '-DNODE_GYP_MODULE_NAME=yara' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_LARGEFILE_SOURCE' '-D__STDC_FORMAT_MACROS' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/src -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/deps/openssl/config -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/deps/openssl/openssl/include -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/deps/uv/include -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/deps/zlib -I/opt/a8c/node-yara/.cache/node-gyp/26.13.0/deps/v8/include -I../node_modules/nan -I../build/yara/include  -fPIC -pthread -Wall -Wextra -Wno-unused-parameter -m64 -O3 -fno-omit-frame-pointer -fno-strict-aliasing -std=gnu++20 -MMD -MF ./Release/.deps/Release/obj.target/yara/src/yara.o.d.raw   -c
Release/obj.target/yara/src/yara.o: ../src/yara.cc ../src/yara.h \
 ../node_modules/nan/nan.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_version.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/errno.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/version.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/unix.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/threadpool.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/linux.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/common.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8config.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-array-buffer.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-local-handle.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-handle-base.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-internal.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8config.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-memory-span.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-object.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/garbage-collected.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/api-constants.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/platform.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/source-location.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-source-location.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-platform.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-source-location.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/trace-trait.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/type-traits.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/name-provider.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-maybe.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/conditional-stack-allocated.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/macros.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/compiler-specific.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-persistent-handle.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-weak-callback-info.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-primitive.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-data.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-value.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-sandbox.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-traced-handle.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-platform.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-container.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-context.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-snapshot.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-isolate.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-callbacks.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-promise.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-debug.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-script.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-message.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-embedder-heap.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-exception.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-function-callback.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-microtask.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-statistics.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-unwinder.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-embedder-state-scope.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-date.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-extension.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-external.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-function.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-template.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-initialization.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-json.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-locker.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-microtask-queue.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-primitive-object.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-proxy.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-regexp.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-typed-array.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-value-serializer.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-version.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-wasm.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_version.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_api_types.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/js_native_api_types.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_buffer.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node.h \
 /opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_object_wrap.h \
 ../node_modules/nan/nan_callbacks.h \
 ../node_modules/nan/nan_callbacks_12_inl.h \
 ../node_modules/nan/nan_maybe_43_inl.h \
 ../node_modules/nan/nan_converters.h \
 ../node_modules/nan/nan_converters_43_inl.h \
 ../node_modules/nan/nan_new.h \
 ../node_modules/nan/nan_implementation_12_inl.h \
 ../node_modules/nan/nan_persistent_12_inl.h \
 ../node_modules/nan/nan_weak.h ../node_modules/nan/nan_object_wrap.h \
 ../node_modules/nan/nan_private.h \
 ../node_modules/nan/nan_typedarray_contents.h \
 ../node_modules/nan/nan_json.h ../node_modules/nan/nan_scriptorigin.h \
 ../build/yara/include/yara.h ../build/yara/include/yara/compiler.h \
 ../build/yara/include/yara/ahocorasick.h \
 ../build/yara/include/yara/atoms.h ../build/yara/include/yara/limits.h \
 ../build/yara/include/yara/utils.h ../build/yara/include/yara/re.h \
 ../build/yara/include/yara/arena.h ../build/yara/include/yara/integers.h \
 ../build/yara/include/yara/stream.h \
 ../build/yara/include/yara/sizedstr.h ../build/yara/include/yara/utils.h \
 ../build/yara/include/yara/types.h ../build/yara/include/yara/bitmask.h \
 ../build/yara/include/yara/hash.h ../build/yara/include/yara/stopwatch.h \
 ../build/yara/include/yara/threading.h \
 ../build/yara/include/yara/notebook.h \
 ../build/yara/include/yara/filemap.h ../build/yara/include/yara/error.h \
 ../build/yara/include/yara/filemap.h ../build/yara/include/yara/hash.h \
 ../build/yara/include/yara/libyara.h ../build/yara/include/yara/mem.h \
 ../build/yara/include/yara/modules.h ../build/yara/include/yara/error.h \
 ../build/yara/include/yara/exec.h ../build/yara/include/yara/rules.h \
 ../build/yara/include/yara/scanner.h ../build/yara/include/yara/scan.h \
 ../build/yara/include/yara/libyara.h ../build/yara/include/yara/object.h \
 ../build/yara/include/yara/object.h ../build/yara/include/yara/scanner.h \
 ../build/yara/include/yara/stream.h \
 ../build/yara/include/yara/strutils.h ../build/yara/include/yara/utils.h
../src/yara.cc:
../src/yara.h:
../node_modules/nan/nan.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_version.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/errno.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/version.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/unix.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/threadpool.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/uv/linux.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/common.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8config.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-array-buffer.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-local-handle.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-handle-base.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-internal.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8config.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-memory-span.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-object.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/garbage-collected.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/api-constants.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/platform.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/source-location.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-source-location.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-platform.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-source-location.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/trace-trait.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/type-traits.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/name-provider.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-maybe.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/conditional-stack-allocated.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/macros.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/cppgc/internal/compiler-specific.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-persistent-handle.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-weak-callback-info.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-primitive.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-data.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-value.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-sandbox.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-traced-handle.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-platform.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-container.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-context.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-snapshot.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-isolate.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-callbacks.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-promise.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-debug.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-script.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-message.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-embedder-heap.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-exception.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-function-callback.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-microtask.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-statistics.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-unwinder.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-embedder-state-scope.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-date.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-extension.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-external.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-function.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-template.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-initialization.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-json.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-locker.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-microtask-queue.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-primitive-object.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-proxy.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-regexp.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-typed-array.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-value-serializer.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-version.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/v8-wasm.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_version.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_api_types.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/js_native_api_types.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_buffer.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node.h:
/opt/a8c/node-yara/.cache/node-gyp/26.13.0/include/node/node_object_wrap.h:
../node_modules/nan/nan_callbacks.h:
../node_modules/nan/nan_callbacks_12_inl.h:
../node_modules/nan/nan_maybe_43_inl.h:
../node_modules/nan/nan_converters.h:
../node_modules/nan/nan_converters_43_inl.h:
../node_modules/nan/nan_new.h:
../node_modules/nan/nan_implementation_12_inl.h:
../node_modules/nan/nan_persistent_12_inl.h:
../node_modules/nan/nan_weak.h:
../node_modules/nan/nan_object_wrap.h:
../node_modules/nan/nan_private.h:
../node_modules/nan/nan_typedarray_contents.h:
../node_modules/nan/nan_json.h:
../node_modules/nan/nan_scriptorigin.h:
../build/yara/include/yara.h:
../build/yara/include/yara/compiler.h:
../build/yara/include/yara/ahocorasick.h:
../build/yara/include/yara/atoms.h:
../build/yara/include/yara/limits.h:
../build/yara/include/yara/utils.h:
../build/yara/include/yara/re.h:
../build/yara/include/yara/arena.h:
../build/yara/include/yara/integers.h:
../build/yara/include/yara/stream.h:
../build/yara/include/yara/sizedstr.h:
../build/yara/include/yara/utils.h:
../build/yara/include/yara/types.h:
../build/yara/include/yara/bitmask.h:
../build/yara/include/yara/hash.h:
../build/yara/include/yara/stopwatch.h:
../build/yara/include/yara/threading.h:
../build/yara/include/yara/notebook.h:
../build/yara/include/yara/filemap.h:
../build/yara/include/yara/error.h:
../build/yara/include/yara/filemap.h:
../build/yara/include/yara/hash.h:
../build/yara/include/yara/libyara.h:
../build/yara/include/yara/mem.h:
../build/yara/include/yara/modules.h:
../build/yara/include/yara/error.h:
../build/yara/include/yara/exec.h:
../build/yara/include/yara/rules.h:
../build/yara/include/yara/scanner.h:
../build/yara/include/yara/scan.h:
../build/yara/include/yara/libyara.h:
../build/yara/include/yara/object.h:
../build/yara/include/yara/object.h:
../build/yara/include/yara/scanner.h:
../build/yara/include/yara/stream.h:
../build/yara/include/yara/strutils.h:
../build/yara/include/yara/utils.h:
