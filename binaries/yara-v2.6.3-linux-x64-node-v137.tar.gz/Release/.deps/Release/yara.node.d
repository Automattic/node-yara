cmd_Release/yara.node := ln -f "Release/obj.target/yara.node" "Release/yara.node" 2>/dev/null || (rm -rf "Release/yara.node" && cp -af "Release/obj.target/yara.node" "Release/yara.node")
